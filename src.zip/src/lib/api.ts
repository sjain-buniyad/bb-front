import Cookies from "js-cookie";

const API_URL = "http://localhost:3000";

interface RequestOptions extends RequestInit {
  noAuth?: boolean;
}

export function getToken(): string | undefined {
  return Cookies.get("auth_token");
}

export function setToken(token: string): void {
  Cookies.set("auth_token", token, { expires: 7, sameSite: "lax", path: "/" });
}

export function removeToken(): void {
  Cookies.remove("auth_token", { path: "/" });
}

export async function apiRequest<T>(
  endpoint: string,
  options: RequestOptions = {},
): Promise<T> {
  const { noAuth = false, ...fetchOptions } = options;
  const headers: Record<string, string> = {
    "Content-Type": "application/json",
    ...(fetchOptions.headers as Record<string, string>),
  };
  if (!noAuth) {
    const token = getToken();
    if (token) headers["Authorization"] = `Bearer ${token}`;
  }
  const url = endpoint.startsWith("http") ? endpoint : `${API_URL}${endpoint}`;
  console.log("[apiRequest]", fetchOptions.method, url);
  const response = await fetch(url, { ...fetchOptions, headers });
  console.log("[apiRequest] status:", response.status);

  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(
      data.error || data.message || `Request failed (${response.status})`,
    );
  }
  return data as T;
}

export interface SignupPayload {
  name: string;
  email?: string;
  role: string;
  username?: string;
  password: string;
}
export interface LoginPayload {
  identifier: string;
  password: string;
}
export interface AuthResponse {
  token: string;
  user: {
    _id: string;
    name: string;
    email?: string;
    username?: string;
    role: number;
    avatar?: string;
    verified: boolean;
    provider: string;
  };
}

export async function signup(payload: SignupPayload): Promise<AuthResponse> {
  const res = await apiRequest<AuthResponse>("/signup", {
    method: "POST",
    body: JSON.stringify(payload),
    noAuth: true,
  });
  setToken(res.token);
  return res;
}

export async function login(payload: LoginPayload): Promise<AuthResponse> {
  console.log("[login] payload:", payload);
  const res = await apiRequest<AuthResponse>("/login", {
    method: "POST",
    body: JSON.stringify(payload),
    noAuth: true,
  });
  setToken(res.token);
  return res;
}

export async function googleVerify(payload: {
  idToken: string;
}): Promise<AuthResponse> {
  const res = await apiRequest<AuthResponse>("/auth/google/verify", {
    method: "POST",
    body: JSON.stringify(payload),
    noAuth: true,
  });
  setToken(res.token);
  return res;
}

export async function fetchCurrentUser() {
  return apiRequest<AuthResponse["user"]>("/me");
}

export async function createEmployee(payload: {
  name: string;
  email: string;
  password: string;
  role: string;
}) {
  return apiRequest("/user", {
    method: "POST",
    body: JSON.stringify(payload),
  });
}

export interface Employee {
  _id: string;
  name: string;
  email?: string;
  role: number;
  avatar?: string;
  verified: boolean;
  provider: string;
  adminId?: string;
  createAt?: string;
}

export async function fetchEmployees(): Promise<Employee[]> {
  return apiRequest<Employee[]>("/user");
}

export async function getEmployee(id: string): Promise<Employee> {
  return apiRequest<Employee>(`/user/${id}`);
}

export async function updateEmployee(
  id: string,
  data: Partial<Pick<Employee, "name" | "email" | "role">>,
): Promise<Employee> {
  return apiRequest<Employee>(`/user/${id}`, {
    method: "PATCH",
    body: JSON.stringify(data),
  });
}

export async function deleteEmployee(id: string): Promise<{ message: string }> {
  return apiRequest<{ message: string }>(`/user/${id}`, {
    method: "DELETE",
  });
}

export const ROLE = { SUPER_ADMIN: 1, ADMIN: 512, USER: 1024 } as const;
const ROLE_LABEL: Record<number | string, string> = {
  [ROLE.SUPER_ADMIN]: "super-admin",
  [ROLE.ADMIN]: "admin",
  [ROLE.USER]: "user",
  "super-admin": "super-admin",
  admin: "admin",
  user: "user",
};
export const getRoleLabel = (role: number | string): string =>
  ROLE_LABEL[role] || "user";

// ── Projects ──

export interface Project {
  _id: string;
  adminId: string;
  name: string;
  type: string;
  manager: string;
  developer: string;
  contrator: string;
  consultant: string;
  start_date: string;
  end_date: string;
  bar_length: number;
  description: string;
}

export interface CreateProjectPayload {
  name: string;
  type: string;
  manager: string;
  developer: string;
  contrator: string;
  consultant: string;
  start_date: string;
  end_date: string;
  bar_length: number;
  description: string;
}

export async function fetchProjects(): Promise<Project[]> {
  return apiRequest<Project[]>("/project");
}

export async function getProject(id: string): Promise<Project> {
  return apiRequest<Project>(`/project/${id}`);
}

export async function createProject(
  data: CreateProjectPayload,
): Promise<Project> {
  return apiRequest<Project>("/project", {
    method: "POST",
    body: JSON.stringify(data),
  });
}

export async function updateProject(
  id: string,
  data: Partial<CreateProjectPayload>,
): Promise<Project> {
  return apiRequest<Project>(`/project/${id}`, {
    method: "PATCH",
    body: JSON.stringify(data),
  });
}

export async function deleteProject(id: string): Promise<{ message: string }> {
  return apiRequest<{ message: string }>(`/project/${id}`, {
    method: "DELETE",
  });
}

// ── Blocks ──

export interface Block {
  _id: string;
  name: string;
  description?: string;
  projectId: string;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}

export async function fetchBlocks(projectId: string): Promise<Block[]> {
  const data = await apiRequest<Block[] | { data: Block[] }>(
    `/block?projectId=${projectId}`,
  );
  return Array.isArray(data) ? data : data.data || [];
}

export async function createBlock(payload: {
  name: string;
  description?: string;
  projectId: string;
}): Promise<Block> {
  return apiRequest<Block>("/block", {
    method: "POST",
    body: JSON.stringify(payload),
  });
}

export async function updateBlock(
  id: string,
  payload: { name: string; description?: string },
): Promise<Block> {
  return apiRequest<Block>(`/block/${id}`, {
    method: "PUT", // or "PATCH" depending on what your backend service.ts uses. You used "PUT" earlier.
    body: JSON.stringify(payload),
  });
}

export async function deleteBlock(id: string): Promise<{ message: string }> {
  return apiRequest<{ message: string }>(`/block/${id}`, {
    method: "DELETE",
  });
}
