"use client";

import { useEffect, useRef, useState } from "react";
import { useAuth } from "../../../lib/auth-context";
import {
  createEmployee,
  fetchEmployees,
  updateEmployee,
  deleteEmployee,
  type Employee,
} from "../../../lib/api";
import AuthGuard from "../../../components/AuthGuard";
import Sidebar from "../../../components/Sidebar";
import TopHeader from "../../../components/TopHeader";
import Toast from "../../../components/Toast";

const ROLE = { SUPER_ADMIN: 1, ADMIN: 512, USER: 1024 } as const;
const ROLE_LABEL: Record<number, string> = { [ROLE.SUPER_ADMIN]: "super-admin", [ROLE.ADMIN]: "admin", [ROLE.USER]: "user" };
const ROLE_FROM_STRING: Record<string, number> = { "super-admin": ROLE.SUPER_ADMIN, admin: ROLE.ADMIN, user: ROLE.USER };
const isAdminRole = (r: number | string) =>
  r === ROLE.ADMIN || r === ROLE.SUPER_ADMIN || r === "admin" || r === "super-admin";
const isUserRole = (r: number | string) =>
  r === ROLE.USER || r === "user";

export default function UsersPage() {
  const { user } = useAuth();
  const mainRef = useRef<HTMLDivElement>(null);
  const [users, setUsers] = useState<Employee[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [openMenuId, setOpenMenuId] = useState<string | null>(null);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [creating, setCreating] = useState(false);
  const [toast, setToast] = useState<{
    message: string;
    type: "success" | "error";
  } | null>(null);
  const [form, setForm] = useState({
    name: "",
    email: "",
    password: "",
    role: "user",
  });

  // Edit modal state
  const [showEditModal, setShowEditModal] = useState(false);
  const [editingUser, setEditingUser] = useState<Employee | null>(null);
  const [editForm, setEditForm] = useState({ name: "", email: "", role: "user" });
  const [updating, setUpdating] = useState(false);

  // Delete confirmation state
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [deletingUser, setDeletingUser] = useState<Employee | null>(null);
  const [deleting, setDeleting] = useState(false);

  const isAdmin = isAdminRole(user?.role ?? "");
  const employeeCount = users.filter((u) => isUserRole(u.role)).length;
  const adminCount = users.filter(
    (u) => isAdminRole(u.role),
  ).length;

  const loadEmployees = async () => {
    try {
      const data = await fetchEmployees();
      const adminAsEmployee = user ? [user as unknown as Employee] : [];
      const merged = [
        ...adminAsEmployee,
        ...data.filter((d) => d._id !== user?._id),
      ];
      setUsers(merged);
    } catch (err: any) {
      if (user) {
        setUsers([user as unknown as Employee]);
      }
      setToast({
        message: err.message || "Failed to load employees",
        type: "error",
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadEmployees();
  }, []);

  // Sync sidebar width
  useEffect(() => {
    const sidebar = document.querySelector("aside");
    const main = mainRef.current;
    if (!sidebar || !main) return;
    const sync = () => {
      main.style.marginLeft = sidebar.offsetWidth + "px";
    };
    sync();
    const obs = new MutationObserver(sync);
    obs.observe(sidebar, {
      attributes: true,
      attributeFilter: ["class", "style"],
    });
    window.addEventListener("resize", sync);
    return () => {
      obs.disconnect();
      window.removeEventListener("resize", sync);
    };
  }, []);

  // Close dropdown on outside click
  useEffect(() => {
    if (!openMenuId) return;
    const handler = () => setOpenMenuId(null);
    document.addEventListener("click", handler);
    return () => document.removeEventListener("click", handler);
  }, [openMenuId]);

  const filteredUsers = users.filter(
    (u) =>
      u.name.toLowerCase().includes(search.toLowerCase()) ||
      (u.email && u.email.toLowerCase().includes(search.toLowerCase())),
  );

  // ── Create ──
  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.email || !form.password) return;
    setCreating(true);
    setToast(null);
    try {
      await createEmployee(form);
      setToast({ message: "Employee added successfully!", type: "success" });
      setForm({ name: "", email: "", password: "", role: "user" });
      setShowCreateModal(false);
      await loadEmployees();
    } catch (err: any) {
      setToast({
        message: err.message || "Failed to add employee",
        type: "error",
      });
    } finally {
      setCreating(false);
    }
  };

  // ── Edit ──
  const openEdit = (u: Employee) => {
    setEditingUser(u);
    setEditForm({ name: u.name, email: u.email || "", role: ROLE_LABEL[u.role] || "user" });
    setShowEditModal(true);
    setOpenMenuId(null);
  };

  const handleEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingUser) return;
    setUpdating(true);
    setToast(null);
    try {
      await updateEmployee(editingUser._id, {
        name: editForm.name,
        email: editForm.email,
        role: ROLE_FROM_STRING[editForm.role] ?? ROLE.USER,
      });
      setToast({ message: "User updated successfully!", type: "success" });
      setShowEditModal(false);
      setEditingUser(null);
      await loadEmployees();
    } catch (err: any) {
      setToast({
        message: err.message || "Failed to update user",
        type: "error",
      });
    } finally {
      setUpdating(false);
    }
  };

  // ── Delete ──
  const openDelete = (u: Employee) => {
    setDeletingUser(u);
    setShowDeleteModal(true);
    setOpenMenuId(null);
  };

  const handleDelete = async () => {
    if (!deletingUser) return;
    setDeleting(true);
    setToast(null);
    try {
      await deleteEmployee(deletingUser._id);
      setToast({ message: "User deleted successfully!", type: "success" });
      setShowDeleteModal(false);
      setDeletingUser(null);
      await loadEmployees();
    } catch (err: any) {
      setToast({
        message: err.message || "Failed to delete user",
        type: "error",
      });
    } finally {
      setDeleting(false);
    }
  };

  const roleBadge: Record<number | string, string> = {
    [ROLE.SUPER_ADMIN]: "bg-red-500/10 text-red-400 border border-red-500/20",
    [ROLE.ADMIN]: "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20",
    [ROLE.USER]: "bg-sky-500/10 text-sky-400 border border-sky-500/20",
    "super-admin": "bg-red-500/10 text-red-400 border border-red-500/20",
    "admin": "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20",
    "user": "bg-sky-500/10 text-sky-400 border border-sky-500/20",
  };

  const pageSize = 10;
  const totalPages = Math.max(1, Math.ceil(filteredUsers.length / pageSize));
  const currentPage = 1;
  const pageUsers = filteredUsers.slice(0, pageSize);
  const startIdx =
    filteredUsers.length === 0 ? 0 : (currentPage - 1) * pageSize + 1;
  const endIdx = Math.min(currentPage * pageSize, filteredUsers.length);

  return (
    <AuthGuard>
      <div className="min-h-screen bg-[#0a0a0a] flex">
        <Sidebar />

        <div
          ref={mainRef}
          className="flex-1 flex flex-col min-h-screen transition-all duration-300"
        >
          <TopHeader />

          <main className="flex-1 p-6 lg:p-8 space-y-6">
            {/* Page Header */}
            <div>
              <h1 className="text-xl font-semibold text-white tracking-tight">
                Manage Users
              </h1>
              <p className="text-sm text-zinc-500 mt-0.5">
                Add employees to your workspace and manage their access
              </p>
            </div>

            {/* ── Add Employee Section ── */}
            {isAdmin && (
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
                {/* Add Employee Card */}
                <div className="lg:col-span-2 relative overflow-hidden rounded-xl border border-[#1e1e1e] bg-gradient-to-br from-[#0e0e0e] to-[#0a0a0a]">
                  <div className="absolute -top-20 -right-20 w-60 h-60 bg-emerald-500/5 rounded-full blur-[80px] pointer-events-none" />

                  <div className="relative p-6 flex flex-col sm:flex-row sm:items-center gap-6">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-3">
                        <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center">
                          <svg
                            className="w-5 h-5 text-emerald-400"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                            strokeWidth={1.8}
                          >
                            <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z"
                            />
                          </svg>
                        </div>
                        <div>
                          <h2 className="text-[15px] font-semibold text-white">
                            Add Employee
                          </h2>
                          <p className="text-[12px] text-zinc-500">
                            Create accounts for your team members
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-4 mb-4">
                        <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-[#111] border border-[#1a1a1a]">
                          <span className="w-2 h-2 rounded-full bg-sky-400" />
                          <span className="text-[12px] text-zinc-400">
                            <span className="text-white font-semibold">
                              {employeeCount}
                            </span>{" "}
                            Employees
                          </span>
                        </div>
                        <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-[#111] border border-[#1a1a1a]">
                          <span className="w-2 h-2 rounded-full bg-emerald-400" />
                          <span className="text-[12px] text-zinc-400">
                            <span className="text-white font-semibold">
                              {adminCount}
                            </span>{" "}
                            Admins
                          </span>
                        </div>
                      </div>

                      <p className="text-[12px] text-zinc-600 leading-relaxed max-w-md">
                        Employees will be linked to your account and can access
                        shared projects. They&apos;ll receive a temporary
                        password to log in for the first time.
                      </p>
                    </div>

                    <div className="sm:ml-auto shrink-0 flex sm:flex-col gap-3">
                      <button
                        onClick={() => setShowCreateModal(true)}
                        className="inline-flex items-center justify-center gap-2 px-6 py-3 rounded-xl bg-emerald-500 text-white font-semibold text-sm hover:bg-emerald-600 active:scale-[0.97] transition-all duration-200 shadow-lg shadow-emerald-500/20"
                      >
                        <svg
                          className="w-4 h-4"
                          fill="none"
                          viewBox="0 0 24 24"
                          stroke="currentColor"
                          strokeWidth={2.5}
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            d="M12 4v16m8-8H4"
                          />
                        </svg>
                        Add Employee
                      </button>
                    </div>
                  </div>
                </div>

                {/* Right: Quick Info Cards */}
                <div className="flex flex-col gap-4">
                  <div className="flex-1 bg-[#0e0e0e] border border-[#1e1e1e] rounded-xl p-5">
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-[10px] font-semibold uppercase tracking-widest text-zinc-600">
                        Total Users
                      </span>
                      <div className="w-7 h-7 rounded-lg bg-[#141414] flex items-center justify-center">
                        <svg
                          className="w-3.5 h-3.5 text-zinc-500"
                          fill="none"
                          viewBox="0 0 24 24"
                          stroke="currentColor"
                          strokeWidth={2}
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z"
                          />
                        </svg>
                      </div>
                    </div>
                    <p className="text-3xl font-bold text-white">
                      {users.length}
                    </p>
                    <p className="text-[11px] text-zinc-600 mt-1">
                      in your workspace
                    </p>
                  </div>

                  <div className="flex-1 bg-[#0e0e0e] border border-[#1e1e1e] rounded-xl p-5">
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-[10px] font-semibold uppercase tracking-widest text-zinc-600">
                        Active Today
                      </span>
                      <div className="w-7 h-7 rounded-lg bg-emerald-500/10 flex items-center justify-center">
                        <svg
                          className="w-3.5 h-3.5 text-emerald-500"
                          fill="none"
                          viewBox="0 0 24 24"
                          stroke="currentColor"
                          strokeWidth={2}
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            d="M5.636 18.364a9 9 0 010-12.728m12.728 0a9 9 0 010 12.728m-9.9-2.829a5 5 0 010-7.07m7.072 0a5 5 0 010 7.07M13 12a1 1 0 11-2 0 1 1 0 012 0z"
                          />
                        </svg>
                      </div>
                    </div>
                    <p className="text-3xl font-bold text-white">&mdash;</p>
                    <p className="text-[11px] text-zinc-600 mt-1">
                      no tracking yet
                    </p>
                  </div>
                </div>
              </div>
            )}

            {/* ── Search ── */}
            <div className="flex items-center gap-3">
              <div className="relative flex-1 max-w-sm">
                <svg
                  className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-600"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                  strokeWidth={2}
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                  />
                </svg>
                <input
                  type="text"
                  placeholder="Search by name or email..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="w-full py-2 pl-9 pr-4 rounded-lg text-sm bg-[#111] border border-[#1e1e1e] text-white placeholder:text-zinc-600 focus:border-emerald-500/40 focus:ring-1 focus:ring-emerald-500/20 outline-none transition-all"
                />
              </div>
              {isAdmin && (
                <button
                  onClick={() => setShowCreateModal(true)}
                  className="shrink-0 inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-emerald-500 text-white font-medium text-sm hover:bg-emerald-600 active:scale-[0.98] transition-all duration-200"
                >
                  <svg
                    className="w-4 h-4"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                    strokeWidth={2.5}
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M12 4v16m8-8H4"
                    />
                  </svg>
                  New User
                </button>
              )}
            </div>

            {/* ── Table ── */}
            <div className="bg-[#0e0e0e] border border-[#1e1e1e] rounded-xl overflow-hidden">
              {/* Header */}
              <div className="grid grid-cols-12 gap-4 px-5 py-3 border-b border-[#1a1a1a] text-[10px] font-semibold uppercase tracking-widest text-zinc-600">
                <div className="col-span-4">Name</div>
                <div className="col-span-4">Email</div>
                <div className="col-span-2">Role</div>
                <div className="col-span-2 text-right pr-1">Action</div>
              </div>

              {/* Body */}
              {loading ? (
                <div className="flex flex-col items-center justify-center py-16 px-6">
                  <svg
                    className="animate-spin w-6 h-6 text-emerald-400 mb-3"
                    viewBox="0 0 24 24"
                    fill="none"
                  >
                    <circle
                      cx="12"
                      cy="12"
                      r="10"
                      stroke="currentColor"
                      strokeWidth="3"
                      className="opacity-20"
                    />
                    <path
                      d="M4 12a8 8 0 018-8"
                      stroke="currentColor"
                      strokeWidth="3"
                      strokeLinecap="round"
                    />
                  </svg>
                  <p className="text-sm text-zinc-500">Loading employees...</p>
                </div>
              ) : filteredUsers.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-16 px-6">
                  <div className="w-12 h-12 rounded-xl bg-[#141414] border border-[#1e1e1e] flex items-center justify-center mb-3">
                    <svg
                      className="w-5 h-5 text-zinc-700"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                      strokeWidth={1.5}
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"
                      />
                    </svg>
                  </div>
                  <p className="text-sm text-zinc-500 mb-0.5">
                    {search ? "No users found" : "No employees yet"}
                  </p>
                  <p className="text-xs text-zinc-700">
                    {search
                      ? "Try a different search"
                      : 'Click "+ Add Employee" to get started'}
                  </p>
                </div>
              ) : (
                <div className="divide-y divide-[#151515]">
                  {pageUsers.map((u) => (
                    <div
                      key={u._id}
                      className="grid grid-cols-12 gap-4 px-5 py-3.5 items-center hover:bg-[#121212] transition-colors group"
                    >
                      {/* Name */}
                      <div className="col-span-4 flex items-center gap-3 min-w-0">
                        {u.avatar ? (
                          <img
                            src={u.avatar}
                            alt=""
                            className="w-8 h-8 rounded-full object-cover ring-1 ring-[#222] shrink-0"
                          />
                        ) : (
                          <div className="w-8 h-8 rounded-full bg-[#181818] border border-[#252525] flex items-center justify-center text-xs font-semibold text-zinc-400 shrink-0">
                            {u.name.charAt(0).toUpperCase()}
                          </div>
                        )}
                        <div className="min-w-0">
                          <span className="text-sm text-zinc-200 truncate block">
                            {u.name}
                          </span>
                          <span className="text-[10px] text-zinc-600 block">
                            {isUserRole(u.role)
                              ? "Your Employee"
                              : "Workspace Admin"}
                          </span>
                        </div>
                      </div>

                      {/* Email */}
                      <div className="col-span-4 min-w-0">
                        <span className="text-sm text-zinc-500 truncate block">
                          {u.email || "\u2014"}
                        </span>
                      </div>

                      {/* Role */}
                      <div className="col-span-2">
                        <span
                          className={`inline-flex px-2.5 py-0.5 rounded-md text-[11px] font-semibold uppercase tracking-wider ${roleBadge[u.role] || roleBadge[ROLE.USER]}`}
                        >
                          {typeof u.role === "number" ? (ROLE_LABEL[u.role] || "user") : u.role}
                        </span>
                      </div>

                      {/* Action */}
                      <div className="col-span-2 flex justify-end">
                        <div className="relative">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              setOpenMenuId(
                                openMenuId === u._id ? null : u._id,
                              );
                            }}
                            className="p-1.5 rounded-lg text-zinc-600 hover:text-zinc-300 hover:bg-[#1a1a1a] transition-colors"
                          >
                            <svg
                              className="w-5 h-5"
                              fill="currentColor"
                              viewBox="0 0 24 24"
                            >
                              <circle cx="12" cy="5" r="1.5" />
                              <circle cx="12" cy="12" r="1.5" />
                              <circle cx="12" cy="19" r="1.5" />
                            </svg>
                          </button>

                          {openMenuId === u._id && (
                            <div className="absolute right-0 top-full mt-1 w-44 bg-[#161616] border border-[#252525] rounded-lg shadow-xl shadow-black/60 z-50 overflow-hidden animate-fade-in">
                              <button
                                onClick={() => openEdit(u)}
                                className="w-full flex items-center gap-2.5 px-3 py-2.5 text-[13px] text-zinc-300 hover:bg-[#1e1e1e] transition-colors"
                              >
                                <svg
                                  className="w-3.5 h-3.5 text-zinc-500"
                                  fill="none"
                                  viewBox="0 0 24 24"
                                  stroke="currentColor"
                                  strokeWidth={2}
                                >
                                  <path
                                    strokeLinecap="round"
                                    strokeLinejoin="round"
                                    d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z"
                                  />
                                </svg>
                                Edit Details
                              </button>
                              <div className="h-px bg-[#1e1e1e]" />
                              <button
                                onClick={() => openDelete(u)}
                                className="w-full flex items-center gap-2.5 px-3 py-2.5 text-[13px] text-red-400 hover:bg-red-500/10 transition-colors"
                              >
                                <svg
                                  className="w-3.5 h-3.5"
                                  fill="none"
                                  viewBox="0 0 24 24"
                                  stroke="currentColor"
                                  strokeWidth={2}
                                >
                                  <path
                                    strokeLinecap="round"
                                    strokeLinejoin="round"
                                    d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"
                                  />
                                </svg>
                                Remove Employee
                              </button>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Pagination */}
              {filteredUsers.length > 0 && (
                <div className="px-5 py-3 border-t border-[#1a1a1a] flex items-center justify-between">
                  <p className="text-[12px] text-zinc-600">
                    Showing {startIdx} to {endIdx} of {filteredUsers.length}{" "}
                    entries
                  </p>
                  <div className="flex items-center gap-2">
                    <p className="text-[12px] text-zinc-500 mr-2">
                      Page {currentPage} of {totalPages}
                    </p>
                    <button
                      disabled
                      className="px-2.5 py-1 rounded text-[12px] text-zinc-600 border border-[#222] bg-[#111] cursor-not-allowed"
                    >
                      Prev
                    </button>
                    <button className="px-2.5 py-1 rounded text-[12px] text-emerald-400 border border-emerald-500/30 bg-emerald-500/10 font-medium">
                      {currentPage}
                    </button>
                    <button
                      disabled
                      className="px-2.5 py-1 rounded text-[12px] text-zinc-600 border border-[#222] bg-[#111] cursor-not-allowed"
                    >
                      Next
                    </button>
                  </div>
                </div>
              )}
            </div>
          </main>
        </div>

        {/* ── Add Employee Modal ── */}
        {showCreateModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <div
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
              onClick={() => setShowCreateModal(false)}
            />
            <div className="relative w-full max-w-md bg-[#111] border border-[#1e1e1e] rounded-xl shadow-2xl shadow-black/60 animate-slide-up">
              <div className="flex items-center gap-3 px-5 py-4 border-b border-[#1a1a1a]">
                <div className="w-9 h-9 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center shrink-0">
                  <svg
                    className="w-4 h-4 text-emerald-400"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                    strokeWidth={2}
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z"
                    />
                  </svg>
                </div>
                <div className="flex-1">
                  <h2 className="text-[15px] font-semibold text-white">
                    Add New Employee
                  </h2>
                  <p className="text-[11px] text-zinc-500">
                    This user will be linked to your account
                  </p>
                </div>
                <button
                  onClick={() => setShowCreateModal(false)}
                  className="p-1 rounded text-zinc-500 hover:text-white hover:bg-[#1a1a1a] transition-colors"
                >
                  <svg
                    className="w-5 h-5"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                    strokeWidth={2}
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M6 18L18 6M6 6l12 12"
                    />
                  </svg>
                </button>
              </div>

              <form onSubmit={handleCreate} className="p-5 space-y-4">
                <div>
                  <label className="block text-[11px] font-semibold text-zinc-500 mb-1.5 uppercase tracking-wider">
                    Full Name
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Rahul Sharma"
                    value={form.name}
                    onChange={(e) =>
                      setForm({ ...form, name: e.target.value })
                    }
                    className="input-field"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-zinc-500 mb-1.5 uppercase tracking-wider">
                    Email Address
                  </label>
                  <input
                    type="email"
                    required
                    placeholder="employee@company.com"
                    value={form.email}
                    onChange={(e) =>
                      setForm({ ...form, email: e.target.value })
                    }
                    className="input-field"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-zinc-500 mb-1.5 uppercase tracking-wider">
                    Temporary Password
                  </label>
                  <input
                    type="password"
                    required
                    placeholder="Min. 8 characters"
                    value={form.password}
                    onChange={(e) =>
                      setForm({ ...form, password: e.target.value })
                    }
                    className="input-field"
                  />
                  <p className="text-[10px] text-zinc-600 mt-1.5">
                    Employee will be prompted to change this on first login
                  </p>
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-zinc-500 mb-1.5 uppercase tracking-wider">
                    Role
                  </label>
                  <div className="relative">
                    <select
                      value={form.role}
                      onChange={(e) =>
                        setForm({ ...form, role: e.target.value })
                      }
                      className="input-field appearance-none cursor-pointer pr-9"
                    >
                      <option value="user">Employee (User)</option>
                      <option value="admin">Admin</option>
                      {isAdminRole(user?.role ?? "") && user?.role !== ROLE.ADMIN && user?.role !== "admin" && (
                        <option value="super-admin">Super Admin</option>
                      )}
                    </select>
                    <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-zinc-500">
                      <svg
                        className="w-4 h-4"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                        strokeWidth={2}
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          d="M19 9l-7 7-7-7"
                        />
                      </svg>
                    </div>
                  </div>
                </div>

                <div className="flex items-start gap-2.5 px-3 py-2.5 rounded-lg bg-[#0c0c0c] border border-[#1a1a1a]">
                  <svg
                    className="w-4 h-4 text-emerald-500 mt-0.5 shrink-0"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                    strokeWidth={2}
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                    />
                  </svg>
                  <p className="text-[11px] text-zinc-500 leading-relaxed">
                    This employee will be assigned to{" "}
                    <span className="text-zinc-300 font-medium">
                      your workspace
                    </span>{" "}
                    and can access all projects shared with your team.
                  </p>
                </div>

                <div className="flex justify-end gap-3 pt-1">
                  <button
                    type="button"
                    onClick={() => setShowCreateModal(false)}
                    className="px-4 py-2 rounded-lg text-[13px] font-medium text-zinc-400 border border-[#252525] hover:bg-[#1a1a1a] transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={creating}
                    className="px-5 py-2 rounded-lg text-[13px] font-medium text-white bg-emerald-500 hover:bg-emerald-600 disabled:opacity-40 disabled:cursor-not-allowed transition-all"
                  >
                    {creating ? (
                      <span className="flex items-center gap-2">
                        <svg
                          className="animate-spin w-3.5 h-3.5"
                          viewBox="0 0 24 24"
                          fill="none"
                        >
                          <circle
                            cx="12"
                            cy="12"
                            r="10"
                            stroke="currentColor"
                            strokeWidth="3"
                            className="opacity-20"
                          />
                          <path
                            d="M4 12a8 8 0 018-8"
                            stroke="currentColor"
                            strokeWidth="3"
                            strokeLinecap="round"
                          />
                        </svg>
                        Adding...
                      </span>
                    ) : (
                      "Add Employee"
                    )}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* ── Edit User Modal ── */}
        {showEditModal && editingUser && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <div
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
              onClick={() => {
                setShowEditModal(false);
                setEditingUser(null);
              }}
            />
            <div className="relative w-full max-w-md bg-[#111] border border-[#1e1e1e] rounded-xl shadow-2xl shadow-black/60 animate-slide-up">
              <div className="flex items-center gap-3 px-5 py-4 border-b border-[#1a1a1a]">
                <div className="w-9 h-9 rounded-lg bg-sky-500/10 border border-sky-500/20 flex items-center justify-center shrink-0">
                  <svg
                    className="w-4 h-4 text-sky-400"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                    strokeWidth={2}
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z"
                    />
                  </svg>
                </div>
                <div className="flex-1">
                  <h2 className="text-[15px] font-semibold text-white">
                    Edit User
                  </h2>
                  <p className="text-[11px] text-zinc-500">
                    Update {editingUser.name}&apos;s details
                  </p>
                </div>
                <button
                  onClick={() => {
                    setShowEditModal(false);
                    setEditingUser(null);
                  }}
                  className="p-1 rounded text-zinc-500 hover:text-white hover:bg-[#1a1a1a] transition-colors"
                >
                  <svg
                    className="w-5 h-5"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                    strokeWidth={2}
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M6 18L18 6M6 6l12 12"
                    />
                  </svg>
                </button>
              </div>

              <form onSubmit={handleEdit} className="p-5 space-y-4">
                <div>
                  <label className="block text-[11px] font-semibold text-zinc-500 mb-1.5 uppercase tracking-wider">
                    Full Name
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Full name"
                    value={editForm.name}
                    onChange={(e) =>
                      setEditForm({ ...editForm, name: e.target.value })
                    }
                    className="input-field"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-zinc-500 mb-1.5 uppercase tracking-wider">
                    Email Address
                  </label>
                  <input
                    type="email"
                    required
                    placeholder="email@example.com"
                    value={editForm.email}
                    onChange={(e) =>
                      setEditForm({ ...editForm, email: e.target.value })
                    }
                    className="input-field"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-zinc-500 mb-1.5 uppercase tracking-wider">
                    Role
                  </label>
                  <div className="relative">
                    <select
                      value={editForm.role}
                      onChange={(e) =>
                        setEditForm({ ...editForm, role: e.target.value })
                      }
                      className="input-field appearance-none cursor-pointer pr-9"
                    >
                      <option value="user">Employee (User)</option>
                      <option value="admin">Admin</option>
                      {isAdminRole(user?.role ?? "") && user?.role !== ROLE.ADMIN && user?.role !== "admin" && (
                        <option value="super-admin">Super Admin</option>
                      )}
                    </select>
                    <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-zinc-500">
                      <svg
                        className="w-4 h-4"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                        strokeWidth={2}
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          d="M19 9l-7 7-7-7"
                        />
                      </svg>
                    </div>
                  </div>
                </div>

                <div className="flex justify-end gap-3 pt-1">
                  <button
                    type="button"
                    onClick={() => {
                      setShowEditModal(false);
                      setEditingUser(null);
                    }}
                    className="px-4 py-2 rounded-lg text-[13px] font-medium text-zinc-400 border border-[#252525] hover:bg-[#1a1a1a] transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={updating}
                    className="px-5 py-2 rounded-lg text-[13px] font-medium text-white bg-sky-500 hover:bg-sky-600 disabled:opacity-40 disabled:cursor-not-allowed transition-all"
                  >
                    {updating ? (
                      <span className="flex items-center gap-2">
                        <svg
                          className="animate-spin w-3.5 h-3.5"
                          viewBox="0 0 24 24"
                          fill="none"
                        >
                          <circle
                            cx="12"
                            cy="12"
                            r="10"
                            stroke="currentColor"
                            strokeWidth="3"
                            className="opacity-20"
                          />
                          <path
                            d="M4 12a8 8 0 018-8"
                            stroke="currentColor"
                            strokeWidth="3"
                            strokeLinecap="round"
                          />
                        </svg>
                        Saving...
                      </span>
                    ) : (
                      "Save Changes"
                    )}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* ── Delete Confirmation Modal ── */}
        {showDeleteModal && deletingUser && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <div
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
              onClick={() => {
                if (!deleting) {
                  setShowDeleteModal(false);
                  setDeletingUser(null);
                }
              }}
            />
            <div className="relative w-full max-w-sm bg-[#111] border border-[#1e1e1e] rounded-xl shadow-2xl shadow-black/60 animate-slide-up">
              <div className="p-5 text-center">
                <div className="w-12 h-12 rounded-full bg-red-500/10 border border-red-500/20 flex items-center justify-center mx-auto mb-4">
                  <svg
                    className="w-6 h-6 text-red-400"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                    strokeWidth={1.8}
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"
                    />
                  </svg>
                </div>
                <h3 className="text-[15px] font-semibold text-white mb-1">
                  Remove User
                </h3>
                <p className="text-[13px] text-zinc-500 leading-relaxed">
                  Are you sure you want to remove{" "}
                  <span className="text-zinc-300 font-medium">
                    {deletingUser.name}
                  </span>
                  ? This action cannot be undone.
                </p>
              </div>
              <div className="flex gap-3 px-5 pb-5">
                <button
                  onClick={() => {
                    setShowDeleteModal(false);
                    setDeletingUser(null);
                  }}
                  disabled={deleting}
                  className="flex-1 px-4 py-2.5 rounded-lg text-[13px] font-medium text-zinc-400 border border-[#252525] hover:bg-[#1a1a1a] transition-colors disabled:opacity-40"
                >
                  Cancel
                </button>
                <button
                  onClick={handleDelete}
                  disabled={deleting}
                  className="flex-1 px-4 py-2.5 rounded-lg text-[13px] font-medium text-white bg-red-500 hover:bg-red-600 disabled:opacity-40 disabled:cursor-not-allowed transition-all"
                >
                  {deleting ? (
                    <span className="flex items-center justify-center gap-2">
                      <svg
                        className="animate-spin w-3.5 h-3.5"
                        viewBox="0 0 24 24"
                        fill="none"
                      >
                        <circle
                          cx="12"
                          cy="12"
                          r="10"
                          stroke="currentColor"
                          strokeWidth="3"
                          className="opacity-20"
                        />
                        <path
                          d="M4 12a8 8 0 018-8"
                          stroke="currentColor"
                          strokeWidth="3"
                          strokeLinecap="round"
                        />
                      </svg>
                      Removing...
                    </span>
                  ) : (
                    "Remove"
                  )}
                </button>
              </div>
            </div>
          </div>
        )}

        {toast && (
          <Toast
            message={toast.message}
            type={toast.type}
            onClose={() => setToast(null)}
          />
        )}
      </div>
    </AuthGuard>
  );
}
