"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "../../../lib/auth-context";
import {
  fetchProjects,
  createProject,
  updateProject,
  deleteProject,
  type Project,
  type CreateProjectPayload,
} from "../../../lib/api";
import AuthGuard from "../../../components/AuthGuard";
import Sidebar from "../../../components/Sidebar";
import TopHeader from "../../../components/TopHeader";
import Toast from "../../../components/Toast";

const emptyForm: CreateProjectPayload = {
  name: "",
  type: "bbs",
  manager: "",
  developer: "",
  contrator: "",
  consultant: "",
  start_date: "",
  end_date: "",
  bar_length: 12,
  description: "",
};

export default function ProjectsPage() {
  const { user } = useAuth();
  const router = useRouter();
  const mainRef = useRef<HTMLDivElement>(null);
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [openMenuId, setOpenMenuId] = useState<string | null>(null);
  const [toast, setToast] = useState<{
    message: string;
    type: "success" | "error";
  } | null>(null);

  // Create modal
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [form, setForm] = useState<CreateProjectPayload>(emptyForm);
  const [creating, setCreating] = useState(false);

  // Edit modal
  const [showEditModal, setShowEditModal] = useState(false);
  const [editingProject, setEditingProject] = useState<Project | null>(null);
  const [editForm, setEditForm] = useState<CreateProjectPayload>(emptyForm);
  const [updating, setUpdating] = useState(false);

  // Delete modal
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [deletingProject, setDeletingProject] = useState<Project | null>(null);
  const [deleting, setDeleting] = useState(false);

  // ── Load ──
  const loadProjects = async () => {
    try {
      const data = await fetchProjects();
      setProjects(data);
    } catch (err: any) {
      setToast({
        message: err.message || "Failed to load projects",
        type: "error",
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadProjects();
  }, []);

  // Sync sidebar
  useEffect(() => {
    const sidebar = document.querySelector("aside");
    const main = mainRef.current;
    if (!sidebar || !main) return;
    const sync = () => {
      main.style.marginLeft = sidebar.offsetWidth + "px";
    };
    sync();
    const obs = new MutationObserver(sync);
    obs.observe(sidebar, {
      attributes: true,
      attributeFilter: ["class", "style"],
    });
    window.addEventListener("resize", sync);
    return () => {
      obs.disconnect();
      window.removeEventListener("resize", sync);
    };
  }, []);

  // Close dropdown
  useEffect(() => {
    if (!openMenuId) return;
    const handler = () => setOpenMenuId(null);
    document.addEventListener("click", handler);
    return () => document.removeEventListener("click", handler);
  }, [openMenuId]);

  const filtered = projects.filter(
    (p) =>
      p.name?.toLowerCase().includes(search.toLowerCase()) ||
      p.manager?.toLowerCase().includes(search.toLowerCase()) ||
      p.type?.toLowerCase().includes(search.toLowerCase()),
  );

  // ── Create ──
  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name) return;
    setCreating(true);
    setToast(null);
    try {
      await createProject(form);
      setToast({ message: "Project created successfully!", type: "success" });
      setForm(emptyForm);
      setShowCreateModal(false);
      await loadProjects();
    } catch (err: any) {
      setToast({
        message: err.message || "Failed to create project",
        type: "error",
      });
    } finally {
      setCreating(false);
    }
  };

  // ── Edit ──
  const openEdit = (p: Project) => {
    setEditingProject(p);
    setEditForm({
      name: p.name || "",
      type: p.type || "bbs",
      manager: p.manager || "",
      developer: p.developer || "",
      contrator: p.contrator || "",
      consultant: p.consultant || "",
      start_date: p.start_date ? p.start_date.slice(0, 10) : "",
      end_date: p.end_date ? p.end_date.slice(0, 10) : "",
      bar_length: p.bar_length || 12,
      description: p.description || "",
    });
    setShowEditModal(true);
    setOpenMenuId(null);
  };

  const handleEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingProject) return;
    setUpdating(true);
    setToast(null);
    try {
      await updateProject(editingProject._id, editForm);
      setToast({ message: "Project updated successfully!", type: "success" });
      setShowEditModal(false);
      setEditingProject(null);
      await loadProjects();
    } catch (err: any) {
      setToast({
        message: err.message || "Failed to update project",
        type: "error",
      });
    } finally {
      setUpdating(false);
    }
  };

  // ── Delete ──
  const openDelete = (p: Project) => {
    setDeletingProject(p);
    setShowDeleteModal(true);
    setOpenMenuId(null);
  };

  const handleDelete = async () => {
    if (!deletingProject) return;
    setDeleting(true);
    setToast(null);
    try {
      await deleteProject(deletingProject._id);
      setToast({ message: "Project deleted successfully!", type: "success" });
      setShowDeleteModal(false);
      setDeletingProject(null);
      await loadProjects();
    } catch (err: any) {
      setToast({
        message: err.message || "Failed to delete project",
        type: "error",
      });
    } finally {
      setDeleting(false);
    }
  };

  const typeBadge: Record<string, string> = {
    bbs: "bg-sky-500/10 text-sky-400 border border-sky-500/20",
    waste: "bg-amber-500/10 text-amber-400 border border-amber-500/20",
  };

  const formatDate = (d?: string) => {
    if (!d) return "\u2014";
    return new Date(d).toLocaleDateString("en-IN", {
      day: "numeric",
      month: "short",
      year: "numeric",
    });
  };

  return (
    <AuthGuard>
      <div className="min-h-screen bg-[#0a0a0a] flex">
        <Sidebar />

        <div
          ref={mainRef}
          className="flex-1 flex flex-col min-h-screen transition-all duration-300"
        >
          <TopHeader />

          <main className="flex-1 p-6 lg:p-8 space-y-6">
            {/* Header */}
            <div>
              <h1 className="text-xl font-semibold text-white tracking-tight">
                Project Management
              </h1>
              <p className="text-sm text-zinc-500 mt-0.5">
                Create and manage your construction projects
              </p>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="bg-[#0e0e0e] border border-[#1e1e1e] rounded-xl p-5">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-[10px] font-semibold uppercase tracking-widest text-zinc-600">
                    Total Projects
                  </span>
                  <div className="w-7 h-7 rounded-lg bg-sky-500/10 flex items-center justify-center">
                    <svg
                      className="w-3.5 h-3.5 text-sky-400"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                      strokeWidth={2}
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z"
                      />
                    </svg>
                  </div>
                </div>
                <p className="text-3xl font-bold text-white">
                  {projects.length}
                </p>
                <p className="text-[11px] text-zinc-600 mt-1">
                  in your workspace
                </p>
              </div>
              <div className="bg-[#0e0e0e] border border-[#1e1e1e] rounded-xl p-5">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-[10px] font-semibold uppercase tracking-widest text-zinc-600">
                    BBS Projects
                  </span>
                  <div className="w-7 h-7 rounded-lg bg-emerald-500/10 flex items-center justify-center">
                    <svg
                      className="w-3.5 h-3.5 text-emerald-400"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                      strokeWidth={2}
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"
                      />
                    </svg>
                  </div>
                </div>
                <p className="text-3xl font-bold text-white">
                  {projects.filter((p) => p.type === "bbs").length}
                </p>
                <p className="text-[11px] text-zinc-600 mt-1">behavior-based</p>
              </div>
              <div className="bg-[#0e0e0e] border border-[#1e1e1e] rounded-xl p-5">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-[10px] font-semibold uppercase tracking-widest text-zinc-600">
                    Waste Projects
                  </span>
                  <div className="w-7 h-7 rounded-lg bg-amber-500/10 flex items-center justify-center">
                    <svg
                      className="w-3.5 h-3.5 text-amber-400"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                      strokeWidth={2}
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4"
                      />
                    </svg>
                  </div>
                </div>
                <p className="text-3xl font-bold text-white">
                  {projects.filter((p) => p.type === "waste").length}
                </p>
                <p className="text-[11px] text-zinc-600 mt-1">
                  waste management
                </p>
              </div>
            </div>

            {/* Search + Add */}
            <div className="flex items-center gap-3">
              <div className="relative flex-1 max-w-sm">
                <svg
                  className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-600"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                  strokeWidth={2}
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                  />
                </svg>
                <input
                  type="text"
                  placeholder="Search projects..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="w-full py-2 pl-9 pr-4 rounded-lg text-sm bg-[#111] border border-[#1e1e1e] text-white placeholder:text-zinc-600 focus:border-emerald-500/40 focus:ring-1 focus:ring-emerald-500/20 outline-none transition-all"
                />
              </div>
              <button
                onClick={() => setShowCreateModal(true)}
                className="shrink-0 inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-emerald-500 text-white font-medium text-sm hover:bg-emerald-600 active:scale-[0.98] transition-all duration-200"
              >
                <svg
                  className="w-4 h-4"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                  strokeWidth={2.5}
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M12 4v16m8-8H4"
                  />
                </svg>
                New Project
              </button>
            </div>

            {/* Table */}
            <div className="bg-[#0e0e0e] border border-[#1e1e1e] rounded-xl overflow-hidden">
              {/* Header */}
              <div className="grid grid-cols-12 gap-4 px-5 py-3 border-b border-[#1a1a1a] text-[10px] font-semibold uppercase tracking-widest text-zinc-600">
                <div className="col-span-3">Project</div>
                <div className="col-span-2">Type</div>
                <div className="col-span-2">Manager</div>
                <div className="col-span-2">Duration</div>
                <div className="col-span-1">Bar Length</div>
                <div className="col-span-2 text-right pr-1">Action</div>
              </div>

              {/* Body */}
              {loading ? (
                <div className="flex flex-col items-center justify-center py-16 px-6">
                  <svg
                    className="animate-spin w-6 h-6 text-emerald-400 mb-3"
                    viewBox="0 0 24 24"
                    fill="none"
                  >
                    <circle
                      cx="12"
                      cy="12"
                      r="10"
                      stroke="currentColor"
                      strokeWidth="3"
                      className="opacity-20"
                    />
                    <path
                      d="M4 12a8 8 0 018-8"
                      stroke="currentColor"
                      strokeWidth="3"
                      strokeLinecap="round"
                    />
                  </svg>
                  <p className="text-sm text-zinc-500">Loading projects...</p>
                </div>
              ) : filtered.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-16 px-6">
                  <div className="w-12 h-12 rounded-xl bg-[#141414] border border-[#1e1e1e] flex items-center justify-center mb-3">
                    <svg
                      className="w-5 h-5 text-zinc-700"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                      strokeWidth={1.5}
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z"
                      />
                    </svg>
                  </div>
                  <p className="text-sm text-zinc-500 mb-0.5">
                    {search ? "No projects found" : "No projects yet"}
                  </p>
                  <p className="text-xs text-zinc-700">
                    {search
                      ? "Try a different search"
                      : 'Click "+ New Project" to get started'}
                  </p>
                </div>
              ) : (
                <div className="divide-y divide-[#151515]">
                  {filtered.map((p) => (
                    <div
                      key={p._id}
                      onClick={() =>
                        router.push(`/dashboard/projects/${p._id}`)
                      }
                      className="grid grid-cols-12 gap-4 px-5 py-3.5 items-center hover:bg-[#121212] transition-colors cursor-pointer"
                    >
                      {/* Project Name */}
                      <div className="col-span-3 min-w-0">
                        <span className="text-sm text-zinc-200 truncate block font-medium">
                          {p.name || "\u2014"}
                        </span>
                        <span className="text-[10px] text-zinc-600 truncate block">
                          {p.description?.slice(0, 40) || "No description"}
                        </span>
                      </div>

                      {/* Type */}
                      <div className="col-span-2">
                        <span
                          className={`inline-flex px-2.5 py-0.5 rounded-md text-[11px] font-semibold uppercase tracking-wider ${typeBadge[p.type] || typeBadge.bbs}`}
                        >
                          {p.type || "bbs"}
                        </span>
                      </div>

                      {/* Manager */}
                      <div className="col-span-2 min-w-0">
                        <span className="text-sm text-zinc-500 truncate block">
                          {p.manager || "\u2014"}
                        </span>
                      </div>

                      {/* Duration */}
                      <div className="col-span-2 min-w-0">
                        <span className="text-[12px] text-zinc-500 block">
                          {formatDate(p.start_date)} &mdash;{" "}
                          {formatDate(p.end_date)}
                        </span>
                      </div>

                      {/* Bar Length */}
                      <div className="col-span-1">
                        <span className="text-sm text-zinc-400">
                          {p.bar_length ?? 12}
                        </span>
                      </div>

                      {/* Action */}
                      <div className="col-span-2 flex justify-end">
                        <div className="relative">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              setOpenMenuId(
                                openMenuId === p._id ? null : p._id,
                              );
                            }}
                            className="p-1.5 rounded-lg text-zinc-600 hover:text-zinc-300 hover:bg-[#1a1a1a] transition-colors"
                          >
                            <svg
                              className="w-5 h-5"
                              fill="currentColor"
                              viewBox="0 0 24 24"
                            >
                              <circle cx="12" cy="5" r="1.5" />
                              <circle cx="12" cy="12" r="1.5" />
                              <circle cx="12" cy="19" r="1.5" />
                            </svg>
                          </button>

                          {openMenuId === p._id && (
                            <div className="absolute right-0 top-full mt-1 w-44 bg-[#161616] border border-[#252525] rounded-lg shadow-xl shadow-black/60 z-50 overflow-hidden animate-fade-in">
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  openEdit(p);
                                }}
                                className="w-full flex items-center gap-2.5 px-3 py-2.5 text-[13px] text-zinc-300 hover:bg-[#1e1e1e] transition-colors"
                              >
                                <svg
                                  className="w-3.5 h-3.5 text-zinc-500"
                                  fill="none"
                                  viewBox="0 0 24 24"
                                  stroke="currentColor"
                                  strokeWidth={2}
                                >
                                  <path
                                    strokeLinecap="round"
                                    strokeLinejoin="round"
                                    d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z"
                                  />
                                </svg>
                                Edit Project
                              </button>
                              <div className="h-px bg-[#1e1e1e]" />
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  openDelete(p);
                                }}
                                className="w-full flex items-center gap-2.5 px-3 py-2.5 text-[13px] text-red-400 hover:bg-red-500/10 transition-colors"
                              >
                                <svg
                                  className="w-3.5 h-3.5"
                                  fill="none"
                                  viewBox="0 0 24 24"
                                  stroke="currentColor"
                                  strokeWidth={2}
                                >
                                  <path
                                    strokeLinecap="round"
                                    strokeLinejoin="round"
                                    d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"
                                  />
                                </svg>
                                Delete Project
                              </button>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Footer */}
              {filtered.length > 0 && (
                <div className="px-5 py-3 border-t border-[#1a1a1a]">
                  <p className="text-[12px] text-zinc-600">
                    Showing {filtered.length} of {projects.length} projects
                  </p>
                </div>
              )}
            </div>
          </main>
        </div>

        {/* ── Create Project Modal ── */}
        {showCreateModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <div
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
              onClick={() => setShowCreateModal(false)}
            />
            <div className="relative w-full max-w-lg max-h-[90vh] overflow-y-auto bg-[#111] border border-[#1e1e1e] rounded-xl shadow-2xl shadow-black/60 animate-slide-up">
              <div className="flex items-center gap-3 px-5 py-4 border-b border-[#1a1a1a] sticky top-0 bg-[#111] z-10">
                <div className="w-9 h-9 rounded-lg bg-sky-500/10 border border-sky-500/20 flex items-center justify-center shrink-0">
                  <svg
                    className="w-4 h-4 text-sky-400"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                    strokeWidth={2}
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M12 4v16m8-8H4"
                    />
                  </svg>
                </div>
                <div className="flex-1">
                  <h2 className="text-[15px] font-semibold text-white">
                    New Project
                  </h2>
                  <p className="text-[11px] text-zinc-500">
                    Create a new construction project
                  </p>
                </div>
                <button
                  onClick={() => setShowCreateModal(false)}
                  className="p-1 rounded text-zinc-500 hover:text-white hover:bg-[#1a1a1a] transition-colors"
                >
                  <svg
                    className="w-5 h-5"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                    strokeWidth={2}
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M6 18L18 6M6 6l12 12"
                    />
                  </svg>
                </button>
              </div>

              <form onSubmit={handleCreate} className="p-5 space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="col-span-2">
                    <label className="block text-[11px] font-semibold text-zinc-500 mb-1.5 uppercase tracking-wider">
                      Project Name *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Metro Rail Phase 2"
                      value={form.name}
                      onChange={(e) =>
                        setForm({ ...form, name: e.target.value })
                      }
                      className="input-field"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-zinc-500 mb-1.5 uppercase tracking-wider">
                      Project Type
                    </label>
                    <div className="relative">
                      <select
                        value={form.type}
                        onChange={(e) =>
                          setForm({ ...form, type: e.target.value })
                        }
                        className="input-field appearance-none cursor-pointer pr-9"
                      >
                        <option value="bbs">BBS</option>
                        <option value="waste">Waste</option>
                      </select>
                      <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-zinc-500">
                        <svg
                          className="w-4 h-4"
                          fill="none"
                          viewBox="0 0 24 24"
                          stroke="currentColor"
                          strokeWidth={2}
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            d="M19 9l-7 7-7-7"
                          />
                        </svg>
                      </div>
                    </div>
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-zinc-500 mb-1.5 uppercase tracking-wider">
                      Bar Length
                    </label>
                    <input
                      type="number"
                      min="1"
                      placeholder="12"
                      value={form.bar_length}
                      onChange={(e) =>
                        setForm({
                          ...form,
                          bar_length: parseInt(e.target.value) || 12,
                        })
                      }
                      className="input-field"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-zinc-500 mb-1.5 uppercase tracking-wider">
                      Manager
                    </label>
                    <input
                      type="text"
                      placeholder="Project manager"
                      value={form.manager}
                      onChange={(e) =>
                        setForm({ ...form, manager: e.target.value })
                      }
                      className="input-field"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-zinc-500 mb-1.5 uppercase tracking-wider">
                      Developer
                    </label>
                    <input
                      type="text"
                      placeholder="Developer name"
                      value={form.developer}
                      onChange={(e) =>
                        setForm({ ...form, developer: e.target.value })
                      }
                      className="input-field"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-zinc-500 mb-1.5 uppercase tracking-wider">
                      Contractor
                    </label>
                    <input
                      type="text"
                      placeholder="Contractor name"
                      value={form.contrator}
                      onChange={(e) =>
                        setForm({ ...form, contrator: e.target.value })
                      }
                      className="input-field"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-zinc-500 mb-1.5 uppercase tracking-wider">
                      Consultant
                    </label>
                    <input
                      type="text"
                      placeholder="Consultant name"
                      value={form.consultant}
                      onChange={(e) =>
                        setForm({ ...form, consultant: e.target.value })
                      }
                      className="input-field"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-zinc-500 mb-1.5 uppercase tracking-wider">
                      Start Date
                    </label>
                    <input
                      type="date"
                      value={form.start_date}
                      onChange={(e) =>
                        setForm({ ...form, start_date: e.target.value })
                      }
                      className="input-field"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-zinc-500 mb-1.5 uppercase tracking-wider">
                      End Date
                    </label>
                    <input
                      type="date"
                      value={form.end_date}
                      onChange={(e) =>
                        setForm({ ...form, end_date: e.target.value })
                      }
                      className="input-field"
                    />
                  </div>
                  <div className="col-span-2">
                    <label className="block text-[11px] font-semibold text-zinc-500 mb-1.5 uppercase tracking-wider">
                      Description
                    </label>
                    <textarea
                      rows={3}
                      placeholder="Brief project description..."
                      value={form.description}
                      onChange={(e) =>
                        setForm({ ...form, description: e.target.value })
                      }
                      className="input-field resize-none"
                    />
                  </div>
                </div>

                <div className="flex justify-end gap-3 pt-1">
                  <button
                    type="button"
                    onClick={() => setShowCreateModal(false)}
                    className="px-4 py-2 rounded-lg text-[13px] font-medium text-zinc-400 border border-[#252525] hover:bg-[#1a1a1a] transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={creating}
                    className="px-5 py-2 rounded-lg text-[13px] font-medium text-white bg-emerald-500 hover:bg-emerald-600 disabled:opacity-40 disabled:cursor-not-allowed transition-all"
                  >
                    {creating ? (
                      <span className="flex items-center gap-2">
                        <svg
                          className="animate-spin w-3.5 h-3.5"
                          viewBox="0 0 24 24"
                          fill="none"
                        >
                          <circle
                            cx="12"
                            cy="12"
                            r="10"
                            stroke="currentColor"
                            strokeWidth="3"
                            className="opacity-20"
                          />
                          <path
                            d="M4 12a8 8 0 018-8"
                            stroke="currentColor"
                            strokeWidth="3"
                            strokeLinecap="round"
                          />
                        </svg>
                        Creating...
                      </span>
                    ) : (
                      "Create Project"
                    )}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* ── Edit Project Modal ── */}
        {showEditModal && editingProject && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <div
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
              onClick={() => {
                setShowEditModal(false);
                setEditingProject(null);
              }}
            />
            <div className="relative w-full max-w-lg max-h-[90vh] overflow-y-auto bg-[#111] border border-[#1e1e1e] rounded-xl shadow-2xl shadow-black/60 animate-slide-up">
              <div className="flex items-center gap-3 px-5 py-4 border-b border-[#1a1a1a] sticky top-0 bg-[#111] z-10">
                <div className="w-9 h-9 rounded-lg bg-sky-500/10 border border-sky-500/20 flex items-center justify-center shrink-0">
                  <svg
                    className="w-4 h-4 text-sky-400"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                    strokeWidth={2}
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z"
                    />
                  </svg>
                </div>
                <div className="flex-1">
                  <h2 className="text-[15px] font-semibold text-white">
                    Edit Project
                  </h2>
                  <p className="text-[11px] text-zinc-500">
                    Update {editingProject.name}
                  </p>
                </div>
                <button
                  onClick={() => {
                    setShowEditModal(false);
                    setEditingProject(null);
                  }}
                  className="p-1 rounded text-zinc-500 hover:text-white hover:bg-[#1a1a1a] transition-colors"
                >
                  <svg
                    className="w-5 h-5"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                    strokeWidth={2}
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M6 18L18 6M6 6l12 12"
                    />
                  </svg>
                </button>
              </div>

              <form onSubmit={handleEdit} className="p-5 space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="col-span-2">
                    <label className="block text-[11px] font-semibold text-zinc-500 mb-1.5 uppercase tracking-wider">
                      Project Name
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="Project name"
                      value={editForm.name}
                      onChange={(e) =>
                        setEditForm({ ...editForm, name: e.target.value })
                      }
                      className="input-field"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-zinc-500 mb-1.5 uppercase tracking-wider">
                      Project Type
                    </label>
                    <div className="relative">
                      <select
                        value={editForm.type}
                        onChange={(e) =>
                          setEditForm({ ...editForm, type: e.target.value })
                        }
                        className="input-field appearance-none cursor-pointer pr-9"
                      >
                        <option value="bbs">BBS</option>
                        <option value="waste">Waste</option>
                      </select>
                      <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-zinc-500">
                        <svg
                          className="w-4 h-4"
                          fill="none"
                          viewBox="0 0 24 24"
                          stroke="currentColor"
                          strokeWidth={2}
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            d="M19 9l-7 7-7-7"
                          />
                        </svg>
                      </div>
                    </div>
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-zinc-500 mb-1.5 uppercase tracking-wider">
                      Bar Length
                    </label>
                    <input
                      type="number"
                      min="1"
                      value={editForm.bar_length}
                      onChange={(e) =>
                        setEditForm({
                          ...editForm,
                          bar_length: parseInt(e.target.value) || 12,
                        })
                      }
                      className="input-field"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-zinc-500 mb-1.5 uppercase tracking-wider">
                      Manager
                    </label>
                    <input
                      type="text"
                      value={editForm.manager}
                      onChange={(e) =>
                        setEditForm({ ...editForm, manager: e.target.value })
                      }
                      className="input-field"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-zinc-500 mb-1.5 uppercase tracking-wider">
                      Developer
                    </label>
                    <input
                      type="text"
                      value={editForm.developer}
                      onChange={(e) =>
                        setEditForm({ ...editForm, developer: e.target.value })
                      }
                      className="input-field"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-zinc-500 mb-1.5 uppercase tracking-wider">
                      Contractor
                    </label>
                    <input
                      type="text"
                      value={editForm.contrator}
                      onChange={(e) =>
                        setEditForm({ ...editForm, contrator: e.target.value })
                      }
                      className="input-field"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-zinc-500 mb-1.5 uppercase tracking-wider">
                      Consultant
                    </label>
                    <input
                      type="text"
                      value={editForm.consultant}
                      onChange={(e) =>
                        setEditForm({ ...editForm, consultant: e.target.value })
                      }
                      className="input-field"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-zinc-500 mb-1.5 uppercase tracking-wider">
                      Start Date
                    </label>
                    <input
                      type="date"
                      value={editForm.start_date}
                      onChange={(e) =>
                        setEditForm({ ...editForm, start_date: e.target.value })
                      }
                      className="input-field"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-zinc-500 mb-1.5 uppercase tracking-wider">
                      End Date
                    </label>
                    <input
                      type="date"
                      value={editForm.end_date}
                      onChange={(e) =>
                        setEditForm({ ...editForm, end_date: e.target.value })
                      }
                      className="input-field"
                    />
                  </div>
                  <div className="col-span-2">
                    <label className="block text-[11px] font-semibold text-zinc-500 mb-1.5 uppercase tracking-wider">
                      Description
                    </label>
                    <textarea
                      rows={3}
                      value={editForm.description}
                      onChange={(e) =>
                        setEditForm({
                          ...editForm,
                          description: e.target.value,
                        })
                      }
                      className="input-field resize-none"
                    />
                  </div>
                </div>

                <div className="flex justify-end gap-3 pt-1">
                  <button
                    type="button"
                    onClick={() => {
                      setShowEditModal(false);
                      setEditingProject(null);
                    }}
                    className="px-4 py-2 rounded-lg text-[13px] font-medium text-zinc-400 border border-[#252525] hover:bg-[#1a1a1a] transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={updating}
                    className="px-5 py-2 rounded-lg text-[13px] font-medium text-white bg-sky-500 hover:bg-sky-600 disabled:opacity-40 disabled:cursor-not-allowed transition-all"
                  >
                    {updating ? (
                      <span className="flex items-center gap-2">
                        <svg
                          className="animate-spin w-3.5 h-3.5"
                          viewBox="0 0 24 24"
                          fill="none"
                        >
                          <circle
                            cx="12"
                            cy="12"
                            r="10"
                            stroke="currentColor"
                            strokeWidth="3"
                            className="opacity-20"
                          />
                          <path
                            d="M4 12a8 8 0 018-8"
                            stroke="currentColor"
                            strokeWidth="3"
                            strokeLinecap="round"
                          />
                        </svg>
                        Saving...
                      </span>
                    ) : (
                      "Save Changes"
                    )}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* ── Delete Confirmation Modal ── */}
        {showDeleteModal && deletingProject && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <div
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
              onClick={() => {
                if (!deleting) {
                  setShowDeleteModal(false);
                  setDeletingProject(null);
                }
              }}
            />
            <div className="relative w-full max-w-sm bg-[#111] border border-[#1e1e1e] rounded-xl shadow-2xl shadow-black/60 animate-slide-up">
              <div className="p-5 text-center">
                <div className="w-12 h-12 rounded-full bg-red-500/10 border border-red-500/20 flex items-center justify-center mx-auto mb-4">
                  <svg
                    className="w-6 h-6 text-red-400"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                    strokeWidth={1.8}
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"
                    />
                  </svg>
                </div>
                <h3 className="text-[15px] font-semibold text-white mb-1">
                  Delete Project
                </h3>
                <p className="text-[13px] text-zinc-500 leading-relaxed">
                  Are you sure you want to delete{" "}
                  <span className="text-zinc-300 font-medium">
                    {deletingProject.name}
                  </span>
                  ? This action cannot be undone.
                </p>
              </div>
              <div className="flex gap-3 px-5 pb-5">
                <button
                  onClick={() => {
                    setShowDeleteModal(false);
                    setDeletingProject(null);
                  }}
                  disabled={deleting}
                  className="flex-1 px-4 py-2.5 rounded-lg text-[13px] font-medium text-zinc-400 border border-[#252525] hover:bg-[#1a1a1a] transition-colors disabled:opacity-40"
                >
                  Cancel
                </button>
                <button
                  onClick={handleDelete}
                  disabled={deleting}
                  className="flex-1 px-4 py-2.5 rounded-lg text-[13px] font-medium text-white bg-red-500 hover:bg-red-600 disabled:opacity-40 disabled:cursor-not-allowed transition-all"
                >
                  {deleting ? (
                    <span className="flex items-center justify-center gap-2">
                      <svg
                        className="animate-spin w-3.5 h-3.5"
                        viewBox="0 0 24 24"
                        fill="none"
                      >
                        <circle
                          cx="12"
                          cy="12"
                          r="10"
                          stroke="currentColor"
                          strokeWidth="3"
                          className="opacity-20"
                        />
                        <path
                          d="M4 12a8 8 0 018-8"
                          stroke="currentColor"
                          strokeWidth="3"
                          strokeLinecap="round"
                        />
                      </svg>
                      Deleting...
                    </span>
                  ) : (
                    "Delete"
                  )}
                </button>
              </div>
            </div>
          </div>
        )}

        {toast && (
          <Toast
            message={toast.message}
            type={toast.type}
            onClose={() => setToast(null)}
          />
        )}
      </div>
    </AuthGuard>
  );
}
