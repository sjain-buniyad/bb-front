interface StatCardProps {
  label: string;
  value: string | number;
  icon: React.ReactNode;
  accent?: boolean;
}

export default function StatCard({ label, value, icon, accent }: StatCardProps) {
  return (
    <div className="bg-[#0c0c0e] border border-[#1a1a1e] rounded-xl p-5 flex items-start gap-4 hover:border-[#2a2a2e] transition-colors duration-200">
      <div className={`w-11 h-11 rounded-xl flex items-center justify-center shrink-0 ${
        accent ? "bg-accent/10 text-accent" : "bg-surface-700 text-zinc-400"
      }`}>
        {icon}
      </div>
      <div className="min-w-0">
        <p className="text-2xl font-bold text-white tracking-tight">{value}</p>
        <p className="text-xs text-zinc-500 mt-0.5 truncate">{label}</p>
      </div>
    </div>
  );
}
